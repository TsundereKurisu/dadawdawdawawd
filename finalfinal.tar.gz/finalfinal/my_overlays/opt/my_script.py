from mpd import MPDClient
import gpiod
import time

def bounce(line, timeout):
	event = 0
	new = False
	ev_line = line.event_wait(sec=timeout)
	while ev_line:
		new = True
		event = line.event_read()
		ev_line = line.event_wait(0,150000000)
	if new == False:
		return event
	else:
		return event.type

def bulk_bounce(lines, timeout):
	event = 0
	result = lines.event_wait(sec=timeout)
	if result != None:
		line = result[0]
		read_val = line.event_read()
		olevent = read_val.type
		event = bounce(line, timeout)
		if event == 0:
			event = olevent
		if event == 2 and str(line) == str(lines.to_list()[0]):
			event = 25
		elif event == 2 and str(line) == str(lines.to_list()[1]):
			event = 10
		elif event == 2 and str(line) == str(lines.to_list()[2]):
			event = 17
		elif event == 2 and str(line) == str(lines.to_list()[3]):
			event = 18
	return event

isPaused = False
client = MPDClient()
client.idletimeout = None
client.connect("localhost",6600)
client.play()



chip = gpiod.Chip('gpiochip0')

offsets = [25, 10, 17, 18]
buttons = chip.get_lines(offsets)
buttons.request(consumer='its_me', type=gpiod.LINE_REQ_EV_BOTH_EDGES)
while True:
	eventtt = bulk_bounce(buttons, 2)
	if eventtt == 25:
		if isPaused == False:
			isPaused = True
			client.pause()
		else:
			isPaused = False
			client.play()
	elif eventtt == 10:
		client.next()
	elif eventtt == 17:
		volume = (int)(client.status()['volume'])
		if volume >= 10:
			client.setvol(volume - 10)
	elif eventtt == 18:
		volume = (int)(client.status()['volume'])
		if volume <= 90:
			client.setvol(volume + 10)
